import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userService:UserService, private router:Router) { }

  ngOnInit(): void {
  }

  // dologin(form:any) {
  //   alert("The form is holding "+form.username+", "+form.password)

  //   this.userService.login(form).subscribe(res=> {
  //     //if(res.password == form.password)
  //   })
  // }

  dologin(form:any) {
    alert("inside login")

    this.userService.token(form).subscribe(res=> {
      alert("the token received is "+res)

      let token = res;

      this.userService.loginUser(token);

      this.router.navigate([('/dashboard')])
    })
  }

}
