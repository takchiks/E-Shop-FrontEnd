import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {

  baseurl:string = "http://localhost:8080/";

  constructor(private http:HttpClient) { }

  addToWishist(id:any) {
    return this.http.get(`${this.baseurl}addToWishList/`+id, { responseType: 'text' })
  }

  getProductsInWishList() {
    return this.http.get(`${this.baseurl}getAllProducts`);
  }
}
