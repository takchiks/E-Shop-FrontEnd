import { Component } from '@angular/core';
import { SharedService } from './shared.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EShop';

  message:any;

  constructor(private _sharedService: SharedService) {
    _sharedService.changeEmitted$.subscribe(text => {
        console.log(text);
        this.message = text;
    });
}
}
