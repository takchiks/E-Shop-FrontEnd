import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  baseurl:string = "http://localhost:8080/";

  constructor(private http:HttpClient) { }

  getMessage() {
    return this.http.get(`${this.baseurl}message`, { responseType: 'text' });
  }

  getProducts() {
    return this.http.get(`${this.baseurl}getProducts`);
  }

  getProductById(id:any) {
    return this.http.get(`${this.baseurl}getProduct/`+id);
  }
}
