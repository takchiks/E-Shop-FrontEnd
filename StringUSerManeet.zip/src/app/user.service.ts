import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl:string = "http://localhost:8080/";

  constructor(private http:HttpClient, private router:Router) { }

  register(form:any) {

    return this.http.post(`${this.baseUrl}`+"register", form);
  }

  // login(form:any) {

  //   //this.router.navigate([('login/'+form.username+"/"+form.password)])
  //  return this.http.get(`${this.baseUrl}`+"login/"+form.username);
  // }

token(form:any) {
  return this.http.post(`${this.baseUrl}`+"token", form, {responseType:'text'});
}

loginUser(token:any) {
  localStorage.setItem('token', token);
}

isLoggedIn() {
  var token = localStorage.getItem('token')

  if(token == null || token == '' || token == undefined) {
    return false;
  }
  else {
    return true;
  }
}

}
