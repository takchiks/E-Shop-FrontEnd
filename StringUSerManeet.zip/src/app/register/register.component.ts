import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private userService:UserService, private router:Router) {
   }

  ngOnInit(): void {
  }

  // register(form:any) {
  //   alert("inside register() "+form.username+", "+form.firstName+", "+form.lastName+", "+form.password+", "+form.phone);

  //   this.http.post("http://localhost:8080/register", form, { responseType: 'text' }).subscribe(res=> {
  //     alert("after registration "+res)
  //   })

  //   this.router.navigate([('/login')]);
  // }

  register(form:any) {
    alert("inside register Form..."+form.username+", "+form.password+", "+form.firstName+", "+form.lastName+", "+form.phone+", "+form.email)

    this.userService.register(form).subscribe(res=>{
      
      this.router.navigate([('/login')])
    })
  }
}
