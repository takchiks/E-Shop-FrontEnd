import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { WishlistService } from '../wishlist.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  products:any;

  constructor(private wishListservice:WishlistService, private sharedService:SharedService) { }

  ngOnInit(): void {

      this.wishListservice.getProductsInWishList().subscribe(res=> {
        this.products = res;

        this.sharedService.emitChange("hi, I am sending data..")
      })

  }

}
